#include "Driver.h"

// Instanciar un mapa y un juego 

Driver::Driver(const Conj< Coordenada > & cs)
{
  assert(false);
}

Driver::~Driver()
{
  assert(false);
}

void Driver::agregarPokemon(const Pokemon & p, const Coordenada & c)
{
  assert(false);
}


// TODO: Completar con el resto de las implementaciones